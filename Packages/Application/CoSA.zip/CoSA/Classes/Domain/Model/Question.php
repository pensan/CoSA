<?php
namespace CoSA\Domain\Model;

/*                                                                        *
 * This script belongs to the FLOW3 package "CoSA".                       *
 *                                                                        *
 *                                                                        */

use TYPO3\FLOW3\Annotations as FLOW3;
use Doctrine\ORM\Mapping as ORM;
use CoSA\Domain\Model\Answer as Answer;

/**
 * A Question
 *
 * @FLOW3\Scope("prototype")
 * @FLOW3\Entity
 */
class Question {

	/**
	 * The text
	 * @var string
	 */
	protected $text;

	/**
	 * Get the Question's text
	 *
	 * @return string The Question's text
	 */
	public function getText() {
		return $this->text;
	}

	/**
	 * Sets this Question's text
	 *
	 * @param string $text The Question's text
	 * @return void
	 */
	public function setText($text) {
		$this->text = $text;
	}
}
?>