<?php
namespace CoSA\Domain\Model;

/*                                                                        *
 * This script belongs to the FLOW3 package "CoSA".                       *
 *                                                                        *
 *                                                                        */

use TYPO3\FLOW3\Annotations as FLOW3;
use Doctrine\ORM\Mapping as ORM;
use CoSA\Domain\Model\Question as Question;

/**
 * A Answer
 *
 * @FLOW3\Scope("prototype")
 * @FLOW3\Entity
 */
class Answer {

	/**
	 * The text
	 * @var string
	 */
	protected $text;
	
	/**
	 * The points
	 * @var integer
	 */
	protected $points;
	
	/**
	 * The question
	 * @var CoSA\Domain\Model\Question
	 * @ORM\ManyToOne
	 */
	protected $question;

	/**
	 * Get the Answer's text
	 *
	 * @return string The Answer's text
	 */
	public function getText() {
		return $this->text;
	}

	/**
	 * Sets this Answer's text
	 *
	 * @param string $text The Answer's text
	 * @return void
	 */
	public function setText($text) {
		$this->text = $text;
	}
	
	/**
	 * Get the Answer's points
	 *
	 * @return integer The Answer's points
	 */
	public function getPoints() {
		return $this->points;
	}

	/**
	 * Sets this Answer's points
	 *
	 * @param integer $points The Answer's points
	 * @return void
	 */
	public function setPoints($points) {
		$this->points = $points;
	}

	/**
	 * Get the Answer's question
	 *
	 * @return CoSA\Domain\Model\Question The Answer's question
	 */
	public function getQuestion() {
		return $this->question;
	}

	/**
	 * Sets this Answer's question
	 *
	 * @param CoSA\Domain\Model\Question $question The Answer's question
	 * @return void
	 */
	public function setQuestion($question) {
		$this->points = $question;
	}

}
?>